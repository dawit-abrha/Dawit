
    var navlinks = document.getElementById("navLinks");
    function showMenu(){
        navlinks.style.right ="0";
    }
    function hideMenu(){
        navlinks.style.right ="-200px";
    }
    

    const goUp = document.getElementById("scrollUpIcon");

window.addEventListener('scroll', iconVisibility);

function iconVisibility() {
      if (window.scrollY > 400) {
        goUp.style.display = "block";
    } else {
        goUp.style.display = "none";
    }
  }

goUp.addEventListener('click', () => {
    window.scrollTo(0, 0);
});
/*-------js for sign up*/
let signupbtn = document.getElementById("signupbtn");
let signinbtn = document.getElementById("signinbtn");
let nameField= document.getElementById("nameField");
let title = document.getElementById("title");

signinbtn.onclick = function(){
    nameField.style.maxHeight = "0";
    title.innerHTML = "Sign in";
    signupbtn.classList.add("disable")
    signinbtn.classList.remove("disable")
}
signupbtn.onclick = function(){
    nameField.style.maxHeight = "60px";
    title.innerHTML = "Sign up";
    signupbtn.classList.rdemove("disable")
    signinbtn.classList.add("disable");
}
/*-------js for sign  in validation*/
const name = document.getElementById("name")
const email = document.getElementById("email")
const password= document.getElementById("password")
const form = document.getElementById("form1")
const name_error = document.getElementById("name_error")


signinbtn.addEventListener("sign up",(e)=>{

    if(name.value === ''|| name.value === null){
        e.preventDefault();
        name_error.innerHTML = "Name is required";
    }
});;